function [topfeatures_i, topfeatures_j] = Lucas_Kanade( I, J, topfeatures_i,topfeatures_j ,window )
sigma=0.6;
iter=0;
%%% Smooth I and J for report
% [G_i1,G_j1]=GaussianKernel(sigma);
% I=convolve(I,G_j1')+ convolve(I,G_i1');
% J=convolve(J,G_i1')+ convolve(J,G_j1');
%%%

[Gx, Gy]=GetGradient(I, sigma);

[height,width]=size(topfeatures_i);

for k=1:width
        u=double(zeros(2,1));
        deltau= double(zeros(2,1));
        Z=Compute2x2GradientMatrix(Gx,Gy,topfeatures_i(k),topfeatures_j(k), window);
        while(1)
            err=Compute2x1ErrorVector(I,J,Gx,Gy,topfeatures_i(k),topfeatures_j(k),window,u);
            deltau=Solve2x1LinearSystem(Z,err);
            u(1)=u(1)+deltau(1); % horizontal
            u(2)=u(2)+deltau(2); %vertical
            if (iter == 10)
                break
            end
            if (abs(deltau(1)) <= 0.2 && abs(deltau(2)) <=0.2)
                break
            end
           iter=iter+1;  
        end
        topfeatures_i(k)= topfeatures_i(k)+u(2)% vertical
        topfeatures_j(k)= topfeatures_j(k)+u(1)% horizontal
end

end

