function [Z] = Compute2x2GradientMatrix( Gx, Gy, i, j, window)

ixx=0;
iyy=0;
ixy=0;
w=floor(window/2);
[height,width]=size(Gx);


for offset_i= -w:w
    for offset_j= -w:w
        if (i+offset_i) <= height && (j+offset_j) <= width && (i+offset_i) > 0 && (j+offset_j) > 0
            Gx_inter=Interpolate(Gx, i+offset_i, j+offset_j);
            Gy_inter=Interpolate(Gy, i+offset_i, j+offset_j);
            ixx= ixx + Gx_inter^2;
            iyy= iyy + Gy_inter^2;
            ixy= ixy+ Gx_inter*Gy_inter;
        end
    end
end

Z= [ixx ixy; ixy iyy];

end

