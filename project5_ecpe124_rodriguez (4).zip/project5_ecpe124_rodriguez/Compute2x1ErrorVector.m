function [err] = Compute2x1ErrorVector(I, J, Gx, Gy, i, j, window, u)
[height, width]=size(I);
w=floor(window/2);
err=double(zeros(2,1));


for offset_i=-w:w
    for offset_j=-w:w
        if (i+offset_i) <= height && (j+offset_j) <= width && (i+offset_i) > 0 && (j+offset_j)> 0
            Gx_inter=Interpolate(Gx, i+offset_i, j+offset_j);
            Gy_inter=Interpolate(Gy, i+offset_i, j+offset_j);
            I_inter= Interpolate(I, i+offset_i, j+offset_j);
            J_inter= Interpolate(J, i+u(2)+offset_i,j+u(1)+offset_j);
            diff=(I_inter-J_inter);
            err(1)=err(1)+Gx_inter*diff;
            err(2)=err(2)+Gy_inter*diff;
        end
    end
end


end

