function [ Gx, Gy ] = GetGradient(I, sigma)

[G_i,  G_j]   = GaussianKernel(sigma);
[deriv_Gi, deriv_Gj]  = GaussianDerivativeKernel(sigma);

tempH = convolve(I, G_i');
tempV = convolve(I, G_j');
Gx = convolve(tempH, deriv_Gj');
Gy = convolve(tempV, deriv_Gi');
% figure
% imshow(Gx)
% figure
% imshow(Gy)
end

