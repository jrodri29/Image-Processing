% Project 5: Lucas Kanade Tracking
% Written By: Jacquelin Rodriguez

%---- Part a: Cherry-Picking-----
[FileName, FilePath]= uigetfile('*');
image=imread(strcat(FilePath, FileName));
imshow(image)

%%% asks user to pick seed from image
for k=1:21
    [topfeatures_j(k), topfeatures_i(k)]= ginput(1);
end

%%% Reading in all images form folder
imagefiles = [dir(fullfile(FilePath,'*pgm')),dir(fullfile(FilePath,'*bmp'))] ;      
nfiles = length(imagefiles);    % Number of files found
for ii=1:nfiles
   filename = strcat(FilePath,imagefiles(ii).name);
   currentimage = imread(filename);
   images{ii} = currentimage;
end

%%% Displaying Special Features
color=[255 0 0];
[height, width]=size(image);
if size(image,3) ~= 3 
    rgb_image = repmat(image,[1 1 3]);
    [height1,width1]=size(topfeatures_i);
    for k=1:width1
        for c=1:3
            if topfeatures_i(k) > 1 && topfeatures_j(k) > 1 && topfeatures_i(k) <= height && topfeatures_j(k) <= width
               rgb_image(uint32(topfeatures_i(k)), uint32(topfeatures_j(k)),c)=color(c);
               rgb_image(uint32(topfeatures_i(k))-1,uint32( topfeatures_j(k))-1,c)=color(c);
               rgb_image(uint32(topfeatures_i(k))-1,uint32( topfeatures_j(k))+1,c)=color(c); 
               rgb_image(uint32(topfeatures_i(k))+1, uint32(topfeatures_j(k))-1,c)=color(c);
               rgb_image(uint32(topfeatures_i(k))+1, uint32(topfeatures_j(k))+1,c)=color(c);
            end
          
        end           
    end
    figure('Name','Selected Features','NumberTitle','off')
    imshow(rgb_image)
end

% -------Part 2: Tracking------
window=11;
for ii=1:nfiles
    if ii < nfiles
        I=double(images{ii});
        J=double(images{ii+1});
        [topfeatures_i, topfeatures_j]=Lucas_Kanade(I, J, topfeatures_i, topfeatures_j, window);
        rgb_image = repmat(J,[1 1 3]);
        rgb_image = uint8(rgb_image);
        [height2,width2]=size(topfeatures_i);
        for k=1:width2
            for c=1:3
                if topfeatures_i(k) > 1 && topfeatures_j(k) > 1 && topfeatures_i(k) < height && topfeatures_j(k) < width
                    rgb_image(uint32(topfeatures_i(k)), uint32(topfeatures_j(k)),c)=color(c);
                    rgb_image(uint32(topfeatures_i(k))-1,uint32( topfeatures_j(k))-1,c)=color(c);
                    rgb_image(uint32(topfeatures_i(k))-1,uint32( topfeatures_j(k))+1,c)=color(c); 
                    rgb_image(uint32(topfeatures_i(k))+1, uint32(topfeatures_j(k))-1,c)=color(c);
                    rgb_image(uint32(topfeatures_i(k))+1, uint32(topfeatures_j(k))+1,c)=color(c);
                end
            end           
        end
    figure('Name','Movie of Feature Points','NumberTitle','off')
    imshow(rgb_image)
    end 
end



