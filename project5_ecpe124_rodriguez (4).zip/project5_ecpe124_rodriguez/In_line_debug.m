%In_line_debug

%%% Read 1st file in folder
[FileName, FilePath]= uigetfile('*');
image=imread(strcat(FilePath, FileName));

%%% Get Special Feature Inputs
imshow(image)
for k=1:7
    [topfeatures_j(k), topfeatures_i(k)]= ginput(1);
end

%%% Displaying Image with Special features
color=[255 0 0];
[height, width]=size(image);% size of image
[height1,width1]=size(topfeatures_i);% Size of special features
rgb_image = repmat(image,[1 1 3]);

for k=1:width1
    for c=1:3
        if topfeatures_i(k) > 1 && topfeatures_j(k) > 1 && topfeatures_i(k) <= height && topfeatures_j(k) <= width
            rgb_image(uint32(topfeatures_i(k)), uint32(topfeatures_j(k)),c)=color(c);
            rgb_image(uint32(topfeatures_i(k))-1, uint32(topfeatures_j(k))-1,c)=color(c);
            rgb_image(uint32(topfeatures_i(k))-1, uint32(topfeatures_j(k))+1,c)=color(c); 
            rgb_image(uint32(topfeatures_i(k))+1, uint32(topfeatures_j(k))-1,c)=color(c);
            rgb_image(uint32(topfeatures_i(k))+1, uint32(topfeatures_j(k))+1,c)=color(c);
        end
    end           
end
figure('Name','Selected Features','NumberTitle','off')
imshow(rgb_image)

%%% Reading in all images from folder
imagefiles = [dir(fullfile(FilePath,'*pgm')),dir(fullfile(FilePath,'*bmp'))] ;      
nfiles = length(imagefiles);    % Number of files found
for ii=1:nfiles
   filename = strcat(FilePath,imagefiles(ii).name);
   currentimage = imread(filename);
   images{ii} = currentimage;
end
window=11;
%%% Lucas Kanade Tracking
for ii=1:nfiles
    if ii < nfiles
            I=double(images{ii});
            J=double(images{ii+1});
            sigma=0.6;
            iter=0;
            [Gx, Gy]=GetGradient(I, sigma);
        for k=1:width1
            u=double(zeros(2,1));
            deltau= double(zeros(2,1));
            Z=double(zeros(2,2));
            Z=Compute2x2GradientMatrix(Gx,Gy,topfeatures_i(k),topfeatures_j(k), window);
            while(1)
                err=Compute2x1ErrorVector(I,J,Gx,Gy,topfeatures_i(k),topfeatures_j(k),window,u);
                deltau=Solve2x1LinearSystem(Z,err);
                u(1)=u(1)+deltau(1); % horizontal
                u(2)=u(2)+deltau(2); %vertical
                if (iter == 10)
                    break
                end
                if abs(deltau(1)) <= 0.2 && abs(deltau(2)) <=0.2
                    break
                end
               iter=iter+1;  
            end
            topfeatures_i(k)= topfeatures_i(k)+u(2);% vertical
            topfeatures_j(k)= topfeatures_j(k)+u(1);% horizontal
        end
        %ssd=checkLostFeature(I,J,topfeatures_i(k), topfeatures_j(k));
        rgb_image = repmat(J,[1 1 3]);
        rgb_image = uint8(rgb_image);
        [height2,width2]=size(topfeatures_i);
        for k=1:width2
            for c=1:3
                if topfeatures_i(k) > 1 && topfeatures_j(k) > 1 && topfeatures_i(k) < height && topfeatures_j(k) < width
                    rgb_image(uint32(topfeatures_i(k)), uint32(topfeatures_j(k)),c)=color(c);
                    rgb_image(uint32(topfeatures_i(k))-1,uint32( topfeatures_j(k))-1,c)=color(c);
                    rgb_image(uint32(topfeatures_i(k))-1,uint32( topfeatures_j(k))+1,c)=color(c); 
                    rgb_image(uint32(topfeatures_i(k))+1, uint32(topfeatures_j(k))-1,c)=color(c);
                    rgb_image(uint32(topfeatures_i(k))+1, uint32(topfeatures_j(k))+1,c)=color(c);
                end
            end           
        end
    figure('Name','Movie of Feature Points','NumberTitle','off')
    imshow(rgb_image)
    end 
    pause()
end



