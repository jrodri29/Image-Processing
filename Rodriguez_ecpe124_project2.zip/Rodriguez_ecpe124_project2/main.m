% Project 2
% Written by Jacquelin Rodriguez

%--- Step 1:Clean Threshold-----

%reads in image
[FileName, FilePath]= uigetfile('*');
thres=imread(strcat(FilePath, FileName));

% checks to see if image is grayscale or color 
if size(thres,3) == 3
    [output_new, low, high]= double_threshold(thres);
end
if size(thres,3) ~= 3
    rgb_image = repmat(thres,[1 1 3]);
    rgb_image = cat(3,thres,thres,thres);
    [output_new, low, high]= double_threshold(rgb_image);
    gray_threshold=rgb2gray(output_new);
    gray_threshold2=rgb2gray(low);
    gray_threshold3=rgb2gray(high);   
end

er_image= erosion(output_new);
er_image2= erosion(er_image);
di_image= dilation(er_image2);
di_image2= dilation(di_image);
di_image3= dilation(di_image2);
di_image4= dilation(di_image3);
er_image3= erosion(di_image4);

figure('Name','Clean Threshold Image','NumberTitle','off')
imshow(er_image3)

%---Step 2:Connected Components---
er3_image= uint8(er_image3);

[label_image2, num_components2, label] = connected_components(er3_image);
figure('Name','Connected Component Image','NumberTitle','off')
imshow(label_image2)

%---Step 3:Region Properties---
region_image= uint8(label_image2);

%Label_1
[m00, m01, m10, m02, m20, mu00,  mu11, mu02, mu20,num_pixels, xC, yC]=region_properties(region_image,label(1,1),label(1,2), label(1,3));
label_1=[m00, m01, m10, m02, m20, mu00, mu11, mu02, mu20, xC, yC];
numPixel_1=num_pixels;

%Label_2
[m00, m01, m10, m02, m20, mu00,  mu11, mu02, mu20,num_pixels, xC, yC]=region_properties(region_image,label(2,1),label(2,2), label(2,3));
label_2=[m00, m01, m10, m02, m20, mu00, mu11, mu02, mu20, xC, yC];
numPixel_2=num_pixels;

%Label_3
[m00, m01, m10, m02, m20, mu00, mu11, mu02, mu20, num_pixels, xC, yC]=region_properties(region_image,label(3,1),label(3,2), label(3,3));
label_3=[m00, m01, m10, m02, m20, mu00, mu11, mu02, mu20, xC, yC];
numPixel_3=num_pixels;

%Label_4
[m00, m01, m10, m02, m20, mu00, mu11, mu02, mu20, num_pixels, xC, yC]=region_properties(region_image,label(4,1),label(4,2), label(4,3));
label_4=[m00, m01, m10, m02, m20, mu00, mu11, mu02, mu20, xC, yC];
numPixel_4=num_pixels;

%Label_5
[m00, m01, m10, m02, m20, mu00,  mu11, mu02, mu20, num_pixels, xC, yC]=region_properties(region_image,label(5,1),label(5,2), label(5,3));
label_5=[m00, m01, m10, m02, m20, mu00, mu11, mu02, mu20, xC, yC];
numPixel_5=num_pixels;

%Label_6
[m00, m01, m10, m02, m20, mu00,  mu11, mu02, mu20, num_pixels, xC, yC]=region_properties(region_image,label(6,1),label(6,2), label(6,3));
label_6=[m00, m01, m10, m02, m20, mu00, mu11, mu02, mu20, xC, yC];
numPixel_6=num_pixels;


%---Step 4:Eigen-values,direction,length of major/minor axes, eccentricity---

%Label_1
[eigen_val_min, eigen_val_max, direction, major_length, minor_length, eccentricity, direction_mi]=PCA(label_1);
PCA_label_1=[eigen_val_min, eigen_val_max, direction, major_length, minor_length, eccentricity, direction_mi];

%Label_2
[eigen_val_min, eigen_val_max, direction, major_length, minor_length, eccentricity, direction_mi]=PCA(label_2);
PCA_label_2=[eigen_val_min, eigen_val_max, direction, major_length, minor_length, eccentricity, direction_mi];

%Label_3
[eigen_val_min, eigen_val_max, direction, major_length, minor_length, eccentricity,direction_mi]=PCA(label_3);
PCA_label_3=[eigen_val_min, eigen_val_max, direction, major_length, minor_length, eccentricity, direction_mi];

%Label_4
[eigen_val_min, eigen_val_max, direction, major_length, minor_length, eccentricity,direction_mi]=PCA(label_4);
PCA_label_4=[eigen_val_min, eigen_val_max, direction, major_length, minor_length, eccentricity, direction_mi];

%Label_5
[eigen_val_min, eigen_val_max, direction, major_length, minor_length, eccentricity, direction_mi]=PCA(label_5);
PCA_label_5=[eigen_val_min, eigen_val_max, direction, major_length, minor_length, eccentricity, direction_mi];

%Label_6
[eigen_val_min, eigen_val_max, direction, major_length, minor_length, eccentricity, direction_mi]=PCA(label_6);
PCA_label_6=[eigen_val_min, eigen_val_max, direction, major_length, minor_length, eccentricity, direction_mi];


% ---Step 5: Wall-Following -----
%
[following_image]=wall_following_2(label_image2,label(1,1),label(1,2), label(1,3));
figure
imshow(following_image)



%% ----- Step 6: Drawing Axes and boundries charterization----
%---Drawing Axes----
%Label 1
Label1_x1= [label_1(10)-(cos(PCA_label_1(3))*sqrt(PCA_label_1(2))),label_1(10),label_1(10)+(cos(PCA_label_1(3))*sqrt(PCA_label_1(2)))];
Label1_y1= [label_1(11)-(sin(PCA_label_1(3))*sqrt(PCA_label_1(2))),label_1(11),label_1(11)+(sin(PCA_label_1(3))*sqrt(PCA_label_1(2)))];

Label1_x2= [label_1(10)-(cos(PCA_label_1(7))*sqrt(PCA_label_1(1))),label_1(10),label_1(10)+(cos(PCA_label_1(7))*sqrt(PCA_label_1(1)))];
Label1_y2= [label_1(11)-(sin(PCA_label_1(7))*sqrt(PCA_label_1(1))),label_1(11),label_1(11)+(sin(PCA_label_1(7))*sqrt(PCA_label_1(1)))];


%Label 2
Label2_x1= [label_2(10)-(cos(PCA_label_2(3))*sqrt(PCA_label_2(2))),label_2(10),label_2(10)+(cos(PCA_label_2(3))*sqrt(PCA_label_2(2)))];
Label2_y1= [label_2(11)-(sin(PCA_label_2(3))*sqrt(PCA_label_2(2))),label_2(11),label_2(11)+(sin(PCA_label_2(3))*sqrt(PCA_label_2(2)))];

Label2_x2= [label_2(10)-(cos(PCA_label_2(7))*sqrt(PCA_label_2(1))),label_2(10),label_2(10)+(cos(PCA_label_2(7))*sqrt(PCA_label_2(1)))];
Label2_y2= [label_2(11)-(sin(PCA_label_2(7))*sqrt(PCA_label_2(1))),label_2(11),label_2(11)+(sin(PCA_label_2(7))*sqrt(PCA_label_2(1)))];

%Label 3
Label3_x1= [label_3(10)-(cos(PCA_label_3(3))*sqrt(PCA_label_3(2))),label_3(10),label_3(10)+(cos(PCA_label_3(3))*sqrt(PCA_label_3(2)))];
Label3_y1= [label_3(11)-(sin(PCA_label_3(3))*sqrt(PCA_label_3(2))),label_3(11),label_3(11)+(sin(PCA_label_3(3))*sqrt(PCA_label_3(2)))];

Label3_x2= [label_3(10)-(cos(PCA_label_3(7))*sqrt(PCA_label_3(1))),label_3(10),label_3(10)+(cos(PCA_label_3(7))*sqrt(PCA_label_3(1)))];
Label3_y2= [label_3(11)-(sin(PCA_label_3(7))*sqrt(PCA_label_3(1))),label_3(11),label_3(11)+(sin(PCA_label_3(7))*sqrt(PCA_label_3(1)))];

%Label 4
Label4_x1= [label_4(10)-(cos(PCA_label_4(3))*sqrt(PCA_label_4(2))),label_4(10),label_4(10)+(cos(PCA_label_4(3))*sqrt(PCA_label_4(2)))];
Label4_y1= [label_4(11)-(sin(PCA_label_4(3))*sqrt(PCA_label_4(2))),label_4(11),label_4(11)+(sin(PCA_label_4(3))*sqrt(PCA_label_4(2)))];

Label4_x2= [label_4(10)-(cos(PCA_label_4(7))*sqrt(PCA_label_4(1))),label_4(10),label_4(10)+(cos(PCA_label_4(7))*sqrt(PCA_label_4(1)))];
Label4_y2= [label_4(11)-(sin(PCA_label_4(7))*sqrt(PCA_label_4(1))),label_4(11),label_4(11)+(sin(PCA_label_4(7))*sqrt(PCA_label_4(1)))];

%Label 5
Label5_x1= [label_5(10)-(cos(PCA_label_5(3))*sqrt(PCA_label_5(2))),label_5(10),label_5(10)+(cos(PCA_label_5(3))*sqrt(PCA_label_5(2)))];
Label5_y1= [label_5(11)-(sin(PCA_label_5(3))*sqrt(PCA_label_5(2))),label_5(11),label_5(11)+(sin(PCA_label_5(3))*sqrt(PCA_label_5(2)))];

Label5_x2= [label_5(10)-(cos(PCA_label_5(7))*sqrt(PCA_label_5(1))),label_5(10),label_5(10)+(cos(PCA_label_5(7))*sqrt(PCA_label_5(1)))];
Label5_y2= [label_5(11)-(sin(PCA_label_5(7))*sqrt(PCA_label_5(1))),label_5(11),label_5(11)+(sin(PCA_label_5(7))*sqrt(PCA_label_5(1)))];

%Label 6
Label6_x1= [label_6(10)-(cos(PCA_label_6(3))*sqrt(PCA_label_6(2))),label_6(10),label_6(10)+(cos(PCA_label_6(3))*sqrt(PCA_label_6(2)))];
Label6_y1= [label_6(11)-(sin(PCA_label_6(3))*sqrt(PCA_label_6(2))),label_6(11),label_6(11)+(sin(PCA_label_6(3))*sqrt(PCA_label_6(2)))];

Label6_x2= [label_6(10)-(cos(PCA_label_6(7))*sqrt(PCA_label_6(1))),label_6(10),label_6(10)+(cos(PCA_label_6(7))*sqrt(PCA_label_6(1)))];
Label6_y2= [label_6(11)-(sin(PCA_label_6(7))*sqrt(PCA_label_6(1))),label_6(11),label_6(11)+(sin(PCA_label_6(7))*sqrt(PCA_label_6(1)))];


figure('Name','Draw axes','NumberTitle','off')
imshow(thres)
hold on
plot(Label1_y1,Label1_x1, 'Color','w','Linewidth', 1)
hold on
plot(Label1_y2,Label1_x2, 'Color','w','Linewidth', 1)
hold on
plot(Label2_y1, Label2_x1, 'Color','w','Linewidth', 1)
hold on
plot(Label2_y2, Label2_x2, 'Color','w','Linewidth', 1)
hold on
plot(Label3_y1, Label3_x1, 'Color','w','Linewidth', 1)
hold on
plot(Label3_y2, Label3_x2, 'Color','w','Linewidth', 1)
hold on
plot(Label4_y1, Label4_x1, 'Color','w','Linewidth', 1)
hold on
plot(Label4_y2, Label4_x2, 'Color','w','Linewidth', 1)
hold on
plot(Label5_y1, Label5_x1, 'Color','w','Linewidth', 1)
hold on
plot(Label5_y2, Label5_x2, 'Color','w','Linewidth', 1)
hold on
plot(Label6_y1, Label6_x1, 'Color','w','Linewidth', 1)
hold on
plot(Label6_y2, Label6_x2, 'Color','w','Linewidth', 1)
hold off


% ---Step 5: Wall-Following -----
%
[following_image]=wall_following_2(label_image2,label(1,1),label(1,2), label(1,3));
figure
imshow(following_image)
