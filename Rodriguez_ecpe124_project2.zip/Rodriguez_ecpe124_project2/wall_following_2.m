function [ lab_image ] = wall_following_2(label_image, label_color1, label_color2, label_color3 )

lab_image= double(label_image);
[height, width,h]= size(lab_image);
flag=0;
 
 for i=1:height
        for j=1:height
            if label_image(i,j,1) == label_color1 && label_image(i,j, 2) == label_color2 && label_image(i,j,3) == label_color3  
                flag=1;
            end 
            if (flag == 1)
                break
            end
        end 
        if (flag == 1)
            break
        end
 end
%%--- 
 j1=j
 i1=i
 dir=0; 
 start=0;
 stack_i =[];
 stack_j=[];
%%---
while start ~= 1
    if dir == 0
        while dir == 0 
            if lab_image(i-1,j,1) == 0 && lab_image(i-1,j, 2) == 0 && lab_image(i-1,j,3) == 0 && i >1
                lab_image(i,j,1)=255;
                lab_image(i,j,2)=255;
                lab_image(i,j,3)=255;
                stack_i=[stack_i, i];
                stack_j=[stack_j,j];
                j=j+1;
                dir=1;    
            elseif lab_image(i,j-1,1) == label_color1 && lab_image(i,j-1, 2) == label_color2 && lab_image(i,j-1,3) == label_color3 && j > 1
                lab_image(i,j,1)=255;
                lab_image(i,j,2)=255;
                lab_image(i,j,3)=255;
                stack_i=[stack_i, i];
                stack_j=[stack_j,j];
                %j=j-1;
                dir=3;
            else 
                lab_image(i,j,1)=255;
                lab_image(i,j,2)=255;
                lab_image(i,j,3)=255;
                stack_i=[stack_i, i];
                stack_j=[stack_j,j];
                i=i-1;
                dir=0;
            end 
        end
    elseif dir ==1      
         while dir == 1
            if lab_image(i-1,j,1) == label_color1 && lab_image(i-1,j, 2) == label_color2 && lab_image(i-1,j,3) == label_color3  && i > 1  
                lab_image(i,j,1)=255;
                lab_image(i,j,2)=255;
                lab_image(i,j,3)=255;
                stack_i=[stack_i, i];
                stack_j=[stack_j,j];
                i=i-1;
                dir=0;
            elseif lab_image(i,j+1,1) ==0 && lab_image(i,j+1, 2) == 0 && lab_image(i,j+1,3) == 0 && j < width
                lab_image(i,j,1)=255;
                lab_image(i,j,2)=255;
                lab_image(i,j,3)=255;
                stack_i=[stack_i, i];
                stack_j=[stack_j,j];
                %i=i+1;
                dir=2;
            else        
                lab_image(i,j,1)=255;
                lab_image(i,j,2)=255;
                lab_image(i,j,3)=255;
                stack_i=[stack_i, i];
                stack_j=[stack_j,j];
                j=j+1;
                dir= 1;        
            end
         end    
    elseif dir ==2     
        while dir == 2 
            if lab_image(i,j+1,1) == label_color1 && lab_image(i,j+1, 2) == label_color2 && lab_image(i,j+1,3) == label_color3 && j<width
                lab_image(i,j,1)=255;
                lab_image(i,j,2)=255;
                lab_image(i,j,3)=255;
                stack_i=[stack_i, i];
                stack_j=[stack_j,j];
                j=j+1;
                dir=1;
            elseif lab_image(i+1,j,1) == 0 && lab_image(i+1,j, 2) == 0 && lab_image(i+1,j,3) == 0 &&  i < height
                lab_image(i,j,1)=255;
                lab_image(i,j,2)=255;
                lab_image(i,j,3)=255;
                stack_i=[stack_i, i];
                stack_j=[stack_j,j];
                %j=j-1;
                dir=3;  
            else 
                lab_image(i,j,1)=255;
                lab_image(i,j,2)=255;
                lab_image(i,j,3)=255;
                stack_i=[stack_i, i];
                stack_j=[stack_j,j];
                i=i+1;
                dir= 2;
            end
        end
    else
        while dir == 3 
            if lab_image(i+1,j,1) == label_color1 && lab_image(i+1,j, 2) == label_color2 && lab_image(i+1,j,3) == label_color3 && i<height
                lab_image(i,j,1)=255;
                lab_image(i,j,2)=255;
                lab_image(i,j,3)=255;
                stack_i=[stack_i, i];
                stack_j=[stack_j,j];
                i=i+1;
                dir=2;
            elseif lab_image(i,j-1,1) == 0 && lab_image(i,j-1, 2) == 0 && lab_image(i,j-1,3) == 0 && j >1
                lab_image(i,j,1)=255;
                lab_image(i,j,2)=255;
                lab_image(i,j,3)=255;
                stack_i=[stack_i, i];
                stack_j=[stack_j,j];
                %i=i-1;
                dir=0;
            else
                lab_image(i,j,1)=255;
                lab_image(i,j,2)=255;
                lab_image(i,j,3)=255;
                stack_i=[stack_i, i];
                stack_j=[stack_j,j];
                j=j-1;
                dir= 3;
            end

        end
    end
    
    if j1==j && i1==i %&& lab_image(i,j,1) == 255 && lab_image(i,j,2)== 255 && lab_image(i,j,3) == 255
         start=1;
    end
    %start=start+1;
end


end

