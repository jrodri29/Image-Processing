 function [ rgb_label, num_components,label] = connected_components( threshold_image )

thres_new=double(threshold_image);
[height, width, h] = size(thres_new);

OFF=0;
ON= 255;
num_components=0;

label_image = zeros(height,width);
rgb_label = repmat(label_image,[1 1 3]);
rgb_label = cat(3,label_image,label_image,label_image);

color=[255 0 0;255 255 0;255 0 255; 0 255 255; 0 0 255; 0 255 0; 255 0 0; 255 255 0; 0 0 255; 255 0 255];
label=color;

k=1;

for i=1:height
    for j=1:width
       if rgb_label(i,j,1)== OFF && rgb_label(i,j,2) == OFF && rgb_label(i,j,3) == OFF &&...
            thres_new(i,j,1) == ON && thres_new(i,j,2) == ON && thres_new(i,j,3) == ON
                rgb_label= seperate_floodfill(threshold_image,i,j,label(k,1),label(k,2),label(k,3),rgb_label);
                num_components = num_components+1;
                k=k+1;  
                
       end
    end
    
end




end

