function [ m00, m01, m10, m02, m20, mu00, mu11, mu02, mu20,num_pixels, xC, yC ] = region_properties( connected_image,label_color1, label_color2, label_color3 )

moment_image=double(connected_image);
[height,width,h]=size(moment_image);
m00=0;
m01=0;
m10=0;
m11=0;
m02=0;
m20=0;
num_pixels=0;
for i=1:height
    for j=1:width
        if (moment_image(i,j,1)== label_color1 && moment_image(i,j,2)== label_color2 && moment_image(i,j,3) == label_color3)
          m00=m00+1;
          m01=m01+j;
          m10=m10+i;
          m11=m11+i*j;
          m02=m02+j*j;
          m20=m20+i*i; 
          
          num_pixels=num_pixels+1;
        end
        
     end
end

xC=(m10/m00);
yC=(m01/m00);

mu00=m00;
mu11=m11-xC*m01;
mu20=m20-xC*m10;
mu02=m02-yC*m01;


end

