function [ new_image ] = erosion( Image1 )
%changes image to double and graps height/width
image= double(Image1);
[height, width] =size(image);

%sets On and off valus
ON=255;
OFF=0;
new_image= image;

%computes erioson with an SE of 3x3
for i=1:height
    for j=1:width
        
        if image(i,j) == ON 
            if image(i-1,j) == ON
                if  image(i,j+1) == ON
                    if image(i+1,j) == ON
                        if image(i, j-1) == ON
                            new_image(i,j)= ON;
                        end
                        if image(i, j-1) ~= ON
                            new_image(i,j)=OFF;
                        end
                    end
                    if image(i+1,j) ~= ON
                      new_image(i,j)= OFF;  
                    end
                end
                if image(i,j+1) ~= ON
                    new_image(i,j)= OFF;
                end
            end
            if image(i-1,j) ~= ON
                new_image(i,j)= OFF;
            end
        end 
        if image(i,j)~= ON
            new_image(i,j)=OFF;
        end     

    end
end

end

