function [eigen_value_min,eigen_value_max, direction_ma, major_length, minor_length, eccentricity, direction_mi  ] = PCA( label_num )
m00=label_num(1);
m01=label_num(2);
m10=label_num(3);
m02=label_num(4);
m20=label_num(5);
mu00=label_num(6);
mu11=label_num(7);
mu02=label_num(8);
mu20=label_num(9);

C =[ (mu20/mu00) (mu11/m00);(mu11/mu00) (m02/mu00)];

%computing eigen-value_min
eigen_value_min=(1/(2*mu00))*((mu20+mu02)-sqrt(((mu20-mu02)^2)+4*mu11^2));

%computing eigen-value_max
eigen_value_max =(1/(2*mu00))*((mu20+mu02)+sqrt(((mu20-mu02)^2) + 4*mu11^2));

%computing direction(theta)=major
direction_ma = 0.5*(atan2(2*mu11, mu20-mu02));

%computing direction(theta)=minor
direction_mi = atan(-1/tan(direction_ma));

%computing major and minor axis length
major_length=2*sqrt(eigen_value_max);

minor_length=2*sqrt(eigen_value_min);

%computing eccentricity
eccentricity=sqrt((eigen_value_max - eigen_value_min)/eigen_value_max);

end

