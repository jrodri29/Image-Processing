 function [ rgb_label, num_components,k] = connected_components( marker,label_image)

marker_new=double(marker);
[height, width] = size(marker_new);

OFF=0;
ON= 255;
num_components=0;
rgb_label=label_image;

k=0;

for i=1:height
    for j=1:width
       if rgb_label(i,j)== -1 && marker_new(i,j) == ON 
                rgb_label= floodfill_fron(marker_new,i,j,k,rgb_label);
                num_components = num_components+1;
                k=k+1;                
       end
    end
    
end

end

