function [mod_froniter_i, mod_froniter_j, fp] = push( froniter_i, froniter_j,value_i,value_j, fp )
fp=fp+1;
mod_froniter_i= [froniter_i, value_i]; % pushs i coordinate to stack
mod_froniter_j= [froniter_j, value_j]; % pushs j coordinate to stack
end
