function [ edges ] = LinkEdges( Hystersis )
Hyster=double(Hystersis);
[height,width]=size(Hyster);
edges=Hyster;

for i=1:height
    for j=1:width
        if Hyster(i,j)==125 && i>1 && i<height && j > 1 && j < width
            if Hyster(i-1,j-1) == 255 || Hyster (i-1,j) == 255 || Hyster (i-1,j+1)== 255 ||...
                    Hyster(i,j-1)==255 || Hyster(i,j+1) == 255 ||...
                    Hyster(i+1, j-1) == 255 || Hyster(i+1, j)== 255 || Hyster(i+1, j+1)== 255
                edges(i,j)=255;
            else
                edges(i,j)=0;
            end
        end
    end
end


end

