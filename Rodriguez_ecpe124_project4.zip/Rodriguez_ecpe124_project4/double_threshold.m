function [rgb_output,image_lo, image_hi] = double_threshold(thres)

   thres_image=thres;
   [height, width,h] =size(thres_image);%Find the height and width of image
   %work_image=duble(Image1);%convert image from uint8 to a double

   t_lo= 80;
   t_hi= 130;
   out_lo=thres_image;
   out_hi=thres_image;
   
 %computes low threshold image  
    for i=1:height
        for j=1:width
            if (thres_image(i,j) >= t_lo)
                out_lo(i,j,1)= 255;
                out_lo(i,j,2)= 255;
                out_lo(i,j,3)= 255;
            end
            if (thres_image(i,j) < t_lo)
                out_lo(i,j,1)=0;
                out_lo(i,j,2)=0;
                out_lo(i,j,3)=0;
            end
        end
    end
 %computes high threshhold image   
    for i=1:height
        for j=1:width
            if (thres_image(i,j) >= t_hi)
                out_hi(i,j,1)=255;
                out_hi(i,j,2)=255;
                out_hi(i,j,3)=255;
                
            end
            if (thres_image(i,j) < t_hi)
                out_hi(i,j,1)=0;
                out_hi(i,j,2)=0;
                out_hi(i,j,3)=0;
            end
            
        end
    end
    
   image_lo=uint8(out_lo);
   image_hi=uint8(out_hi);
   output_double = zeros(height,width);
   rgb_output = repmat(output_double,[1 1 3]);
   rgb_output = cat(3,output_double,output_double,output_double);
   
   %computes double threshold image
    for i=1:height
        for j=1:width
            if out_hi(i,j,1) == 255 && out_hi(i,j,2) == 255 && out_hi(i,j,3) == 255 
             
            rgb_output= seperate_floodfill(image_lo,i,j,255,255,255,rgb_output);

            end
        end
    end
    
    for i=1:height
        for j=1:width
             if rgb_output(i,j,1) == 255 && rgb_output(i,j,2) == 255 && rgb_output(i,j,3) == 255
                rgb_output(i,j,1)=0;
                rgb_output(i,j,2)=0;
                rgb_output(i,j,3)=0;
            else
                rgb_output(i,j,1)=255;
                rgb_output(i,j,2)=255;
                rgb_output(i,j,3)=255;
            
            end
        end
    end
    rgb_output= uint8(rgb_output);
    imwrite(rgb_output, 'double_threshold.bmp')
end

