%% Project 4: Watershed
%Written by: Jacquelin Rodriguez

%% Section 1:Normal Watershed
%-----Step 1: Convolve Image----

[FileName, FilePath]= uigetfile('*');
Image1=imread(strcat(FilePath, FileName));
if size(Image1,3) == 3
    grey_image = rgb2gray(Image1);
    grey_image=double(grey_image);
end
if size(Image1,3) ~= 3
    grey_image=Image1;
    grey_image=double(grey_image);
end

sigma=0.6;
[G_i,G_j, w]= GaussianKernel(sigma);
[G_deriv_i,G_deriv_j,w]= GaussianDerivativeKernel(sigma);

[con_h]=convolve(grey_image,G_j);
[con_horizontal]=convolve(con_h,fliplr(G_deriv_i));
%figure('Name','Horizontal Convolve','NumberTitle','off')
%imshow(con_horizontal)

[con_v]=convolve(grey_image,G_i);
[con_vertical]=convolve(con_v,flipud(G_deriv_j));
%figure('Name','Vertical Convolve','NumberTitle','off')
%imshow(con_vertical)

%----- Step 2: Magnitude and Gradient------

[Gxy, Iangle]=MagnitudeAndGradient(con_vertical,con_horizontal);
Gxy=uint8(Gxy);

figure('Name','Normal Watershed: Magnitude','NumberTitle','off')
imshow(Gxy)

%-----Step 3: Watershed---------

[label] = watershed(Gxy);
Lshow=(255*label)/(max(max(label)));
figure('Name','Normal Watershed: Labels','NumberTitle','off')
imshow(uint8(Lshow));

%% Section 2: Marker Watershed
%------Step 1: Watershed Magnitude image-----
[FileName, FilePath]= uigetfile('*');
Image1=imread(strcat(FilePath, FileName));
if size(Image1,3) == 3
    grey_image = rgb2gray(Image1);
    grey_image=double(grey_image);
end
if size(Image1,3) ~= 3
    grey_image=Image1;
    grey_image=double(grey_image);
end

sigma=0.6;
[G_i,G_j, w]= GaussianKernel(sigma);
[G_deriv_i,G_deriv_j,w]= GaussianDerivativeKernel(sigma);

[con_h]=convolve(grey_image,G_j);
[con_horizontal]=convolve(con_h,fliplr(G_deriv_i));

[con_v]=convolve(grey_image,G_i);
[con_vertical]=convolve(con_v,flipud(G_deriv_j));

[Gxy, Iangle]=MagnitudeAndGradient(con_vertical,con_horizontal);

figure('Name','Marker Watershed: Magnitude','NumberTitle','off')
imshow(uint8(Gxy))
%----Step 2: Threshold image----
[thres_image] = double_threshold(grey_image);
thres_image= rgb2gray(thres_image);
figure('Name','Marker Watershed: Threshold','NumberTitle','off')
imshow(thres_image)

%-----Step 3: Chamfer Image----
[chamfer_image]=chamferDistance(thres_image);
chamfer_2=(255*chamfer_image)/(max(max(chamfer_image)));
figure('Name','Marker Watershed: Chamfer','NumberTitle','off')

imshow(uint8(chamfer_2))
%-----Step 4: Watershed ----
[label_2] = watershed(uint8(chamfer_image));
Lshow_2=(255*label_2)/(max(max(label_2)));
figure('Name','Marker Watershed: Watershed of Chamfer','NumberTitle', 'off')
imshow(uint8(Lshow_2))

%----Step 5: Edges-----
sigma=0.6;
[G_i,G_j, w]= GaussianKernel(sigma);
[G_deriv_i,G_deriv_j,w]= GaussianDerivativeKernel(sigma);

[con_h]=convolve(uint8(Lshow_2),G_j);
[con_horizontal]=convolve(con_h,fliplr(G_deriv_i));

[con_v]=convolve(uint8(Lshow_2),G_i);
[con_vertical]=convolve(con_v,flipud(G_deriv_j));

% Magnitude and Gradient
[Gxy, Iangle]=MagnitudeAndGradient(con_vertical,con_horizontal);

%Suppression
[suppressed_image] = Suppression( Gxy, Iangle);

%Hystersis
[ Hyster ] = Hysteresis(suppressed_image );

%Link Edges
[Edges]=LinkEdges(Hyster);
Edges=uint8(Edges);
figure('Name','Marker Watershed: Edges separating objects','NumberTitle','off');
imshow(Edges)

% -------Step 6: ORing threshold and edge image to create marker
[height, width]=size(Edges);
marker=zeros(height,width);
for i=1:height
    for j=1:width
        if Edges(i,j)== 255;
           marker(i,j)=255;
        end
        if thres_image(i,j)==255
            marker(i,j)=255;
        end
    end
end
figure ('Name','Marker Watershed: Watershed Marker','NumberTitle','off');
imshow(marker)

%-----Step 7: Marker based Watershed----

[label_marker]=watershed_marker(uint8(Gxy),marker);
Lshow_mar=(255*label_marker)/(max(max(label_marker)));
figure('Name','Marker Watershed: Label Image','NumberTitle','off')
imshow(uint8(Lshow_mar))
