function [label] = watershed(mag_image)

[height, width] = size(mag_image);
mag_image=uint8(mag_image);

%Part 1: Section a
cell_i{1,256}=[];
cell_j{1,256}=[];

for i_1=1:height
    for j_1=1:width
      intensity= mag_image(i_1,j_1);
      cell_i{intensity+1}=[cell_i{intensity+1} i_1];
      cell_j{intensity+1}=[cell_j{intensity+1} j_1];        
    end
end

%Part 1: section b
label=zeros(height,width);
for i=1:height
    for j=1:width
        label(i,j)= -1;
    end
end

% Part 1: section c
globallabel=0;

% Part 2: section a
g=0;
froniter_i=[];
froniter_j=[];

while g < 256
   temp_label=label;
   
   [height1,width1]=size(cell_i{g+1});
   flag=0;
   if isempty(cell_i{g+1}) == 1
         flag=1;
   end 
   index=1;
   if flag ~= 1
       while index ~= width1+1
           i=cell_i{g+1}(index);
           j=cell_j{g+1}(index);
            if mag_image(i,j) == g   
                if i > 1 && j > 1 && temp_label(i-1,j-1) >=0 
                    label(i,j)=label(i-1,j-1);
                    froniter_i=[froniter_i i];
                    froniter_j=[froniter_j j];
                elseif i > 1 && temp_label(i-1,j) >= 0 
                    label(i,j)=label(i-1,j);
                    froniter_i=[froniter_i i];
                    froniter_j=[froniter_j j];
                elseif i > 1 && j< width && temp_label(i-1,j+1) >= 0 
                    label(i,j)=label(i-1,j+1);
                    froniter_i=[froniter_i i];
                    froniter_j=[froniter_j j];
                elseif  j > 1 && temp_label(i,j-1) >= 0 
                    label(i,j)=label(i,j-1);
                    froniter_i=[froniter_i i];
                    froniter_j=[froniter_j j];
                elseif j < width && temp_label(i,j+1) >= 0
                    label(i,j)=label(i,j+1);
                    froniter_i=[froniter_i i];
                    froniter_j=[froniter_j j];
                elseif i < height && j > 1 && temp_label(i+1,j-1) >= 0 
                    label(i,j)=label(i+1, j-1);
                    froniter_i=[froniter_i i];
                    froniter_j=[froniter_j j];
                elseif i < 1 && temp_label(i+1,j) <= 0 
                    label(i,j)=label(i+1,j);
                    froniter_i=[froniter_i i];
                    froniter_j=[froniter_j j];
                elseif i < height && j < width && temp_label(i+1,j+1) >= 0              
                    label(i,j)=label(i+1,j+1);
                    froniter_i=[froniter_i i];
                    froniter_j=[froniter_j j];
                end         
            end
            index=index+1;
       end
   end
   %----Part 2: section b-----
   flag2=0;
   if isempty(froniter_i)== 1
         flag2=1;
   end 
   while flag2  ~= 1 
       i=froniter_i(1);
       j=froniter_j(1);
       froniter_i(1)=[];
       froniter_j(1)=[];
       if  i >  1 && j > 1 && mag_image(i-1,j-1)== g
           if i > 1 && j > 1 && label(i-1,j-1)== -1
                label(i-1,j-1)=label(i,j);
                froniter_i= [froniter_i i-1];
                froniter_j= [froniter_j j-1];
           end
       elseif i> 1 && mag_image(i-1,j) == g
           if i> 1 && label(i-1,j) == -1
                label(i-1,j)=label(i,j);
                froniter_i= [froniter_i i-1];
                froniter_j= [froniter_j j];
           end
       elseif i > 1 && j <width && mag_image(i-1,j+1) == g 
           if i > 1 && j <width && label(i-1,j+1)== -1
                label(i-1,j+1)=label(i,j);
                froniter_i= [froniter_i i-1];
                froniter_j= [froniter_j j+1];
           end
       elseif j > 1 && mag_image(i,j-1) == g 
           if j > 1 && label(i,j-1)== -1
                label(i,j-1)=label(i,j);
                froniter_i= [froniter_i i];
                froniter_j= [froniter_j j-1];
           end
       elseif j < width && mag_image(i,j+1) == g
           if j < width && label(i,j+1)== -1
                label(i,j+1)=label(i,j);
                froniter_i= [froniter_i i];
                froniter_j= [froniter_j j+1];
           end
       elseif i< height && j> 1 && mag_image(i+1,j-1) == g
           if  i< height && j> 1 && label(i+1, j-1) == -1
                label(i+1, j-1)=label(i,j);
                froniter_i= [froniter_i i+1];
                froniter_j= [froniter_j j-1];
           end
       elseif i < height && mag_image(i+1,j) == g 
           if i < height && label(i+1,j) == -1
                label(i+1,j)=label(i,j);
                froniter_i= [froniter_i i+1];
                froniter_j= [froniter_j j];
           end
       elseif i< height && j< width && mag_image(i+1,j+1) == g 
           if i< height && j< width && label(i+1,j+1) == -1
                label(i+1,j+1)=label(i,j);
                froniter_i= [froniter_i i+1];
                froniter_j= [froniter_j j+1];
           end
       end
       if isempty(froniter_i)== 1
          flag2=1;
       end    
   end
  
   %----- Part 2: Section c-----
   [heightC, widthC]=size(cell_i{g+1});
   flag3=0;
   f_index=1;
   if isempty(cell_i{g+1})== 1
         flag3=1;
   end 
   if flag3 ~= 1
       while f_index ~= widthC+1
           i=cell_i{g+1}(f_index);
           j=cell_j{g+1}(f_index); 

            if mag_image(i,j) == g && label(i,j) == -1
               globallabel=globallabel+1;
               [label]=floodfill_fron(mag_image, i, j, globallabel, label);
               
            end
            f_index=f_index+1;
       end
       
   end 
    g=g+1; 
end

end


