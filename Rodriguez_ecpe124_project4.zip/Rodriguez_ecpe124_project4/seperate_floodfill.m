function [sep_image ] = seperate_floodfill( grey_image, seed_i, seed_j, new_color1,new_color2,new_color3, sep_image )

%changes image to double
old_image= double(grey_image);
[height,width,h]=size(old_image);
%graps old_color from seed
old_color1 = old_image(seed_i, seed_j,1);
old_color2 = old_image(seed_i, seed_j,2);
old_color3 = old_image(seed_i, seed_j,3);

froniter_i=[];
froniter_j=[];
fp=0;

% push and sets new color for seed
[froniter_i, froniter_j,fp]=push (froniter_i,froniter_j,seed_i, seed_j,fp);
sep_image(seed_i, seed_j,1)= new_color1;
sep_image(seed_i, seed_j,2)= new_color2;
sep_image(seed_i, seed_j,3)= new_color3;
%floodfills image
while fp ~=0
    [froniter_i, froniter_j,i, j,fp] = pop(froniter_i,froniter_j,fp);
    if i > 1
      if old_image(i-1,j,1) == old_color1 && old_image(i-1,j,2)== old_color2 && old_image(i-1,j,3) == old_color3
            if i > 1 
                 if ~(sep_image(i-1,j,1) == new_color1 && sep_image(i-1,j, 2) == new_color2 && sep_image(i-1,j,3) == new_color3)
                        [froniter_i,froniter_j,fp]= push (froniter_i,froniter_j, i-1, j,fp);
                         sep_image(i-1,j,1)= new_color1;
                         sep_image(i-1,j,2)= new_color2;
                         sep_image(i-1,j,3)= new_color3;
                 end
           end
      end
    end
    if j< width
            if old_image(i,j+1,1) == old_color1 && old_image(i,j+1,2) == old_color2 && old_image(i,j+1,3) == old_color3
                if j < width 
                    if ~(sep_image(i,j+1,1) == new_color1 && sep_image(i,j+1,2) == new_color2 && sep_image(i,j+1,3) == new_color3)
                        [froniter_i,froniter_j,fp]=push(froniter_i, froniter_j,i, j+1, fp);
                        sep_image(i, j+1,1)= new_color1;
                        sep_image(i, j+1,2)= new_color2;
                        sep_image(i, j+1,3)= new_color3;
                    end
                end  
            end
    end
    if i< height
            if old_image(i+1,j,1) == old_color1 && old_image(i+1,j,2) == old_color2  && old_image(i+1,j,3) == old_color3 
                if i < height 
                    if ~(sep_image(i+1, j,1) == new_color1 && sep_image(i+1, j,2) == new_color2 && sep_image(i+1, j,3) == new_color3)
                        [froniter_i,froniter_j,fp]= push(froniter_i,froniter_j, i+1, j, fp);
                         sep_image(i+1,j,1) = new_color1;
                         sep_image(i+1,j,2) = new_color2;
                         sep_image(i+1,j,3) = new_color3;
                    end
                end    
            end
    end
    if j> 1
            if old_image(i, j-1,1) == old_color1 && old_image(i, j-1,2) == old_color2 && old_image(i, j-1,3) == old_color3 
                if j > 1 
                    if ~(sep_image(i, j-1,1) == new_color1 && sep_image(i, j-1,2) == new_color2 && sep_image(i, j-1,3) == new_color3)
                        [froniter_i,froniter_j,fp] = push(froniter_i, froniter_j, i, j-1,fp);
                        sep_image(i, j-1,1) = new_color1;
                        sep_image(i, j-1,2) = new_color2;
                        sep_image(i, j-1,3) = new_color3;
                    end
                end
            end
    end
     
end
%new_sep= uint8(sep_image);
end

