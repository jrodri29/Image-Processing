function[sep_image]=  floodfill_fron(grey_image, seed_i,seed_j, new_color, sep_image)

image = grey_image; % image goes from uint8 to double
[height, width] =size(image);% get height and width of image
old_color = image(seed_i, seed_j); % the intensity of seed is saved 

%checking to see if old_color is the same as the new. if so 
if (old_color == new_color)
    return
end

froniter_i =[];
froniter_j =[];
fp=0;

[froniter_i,froniter_j,fp] = push(froniter_i, froniter_j, seed_i, seed_j, fp);
sep_image(seed_i, seed_j)= new_color;

while fp ~= 0
            [froniter_i, froniter_j,i, j,fp] = pop(froniter_i,froniter_j,fp);
            
            if i > 1 && image(i-1,j) == old_color 
                if  sep_image(i-1,j) ~= new_color
                  [froniter_i,froniter_j,fp]= push (froniter_i,froniter_j, i-1, j,fp);
                   sep_image(i-1,j)= new_color;
                end
            end
            if j < width && image(i,j+1) == old_color 
                if sep_image(i,j+1) ~= new_color
                    [froniter_i,froniter_j,fp]=push(froniter_i, froniter_j,i, j+1, fp);
                    sep_image(i, j+1) =new_color;
                end
            end
            if  i < height && image(i+1,j) == old_color 
                if sep_image(i+1,j) ~= new_color
                   [froniter_i,froniter_j,fp]= push(froniter_i,froniter_j, i+1, j, fp);
                    sep_image(i+1,j) = new_color;
                end
            end
            if j > 1 && image(i, j-1) == old_color 
                if sep_image(i, j-1) ~= new_color
                    [froniter_i,froniter_j,fp] = push(froniter_i, froniter_j, i, j-1,fp);
                    sep_image(i, j-1) =new_color;
                end
            end
end         
 
end

