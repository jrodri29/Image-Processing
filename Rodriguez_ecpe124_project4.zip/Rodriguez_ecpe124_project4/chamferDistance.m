function [chamfer_image] = chamferDistance(edges)
[height,width]=size(edges);
chamfer_image= zeros(height,width);
left =0;
for i = 1:height
    for j = 1:width
        if(edges(i,j)==255)
            chamfer_image(i,j)=0;
        else
            if(i-1 >0 )
                top= chamfer_image(i-1,j);
            end
            if (j-1 >0)
                left = chamfer_image(i,j-1);
            end
            if (~(i-1 >0))
                top = inf;
            end
            if(~(j-1 >0))
                left = inf;
            end
            chamfer_image(i,j)=min([left+1,top+1]);
        end
    end
end
for i = height:-1:1
    for j = width:-1:1
        if(~(chamfer_image(i,j)==0))
            
            if(i+1 <=height)
                bottom = chamfer_image(i+1,j);
            end
            if(j+1 <=width)
                right = chamfer_image(i,j+1);
            end
            if(~(i+1 <=height))
                bottom = inf;
            end
            if(~(j+1 <= width))
                right =inf;
            end
            
            chamfer_image(i,j)=min([chamfer_image(i,j),right+1,bottom+1]);
         end
    end
end


end