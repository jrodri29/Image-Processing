function [ Hyster ] = Hysteresis(suppressed_image )
suppressed= suppressed_image;
[height, width]=size(suppressed_image);

h=zeros(1,width*height);
k=1;
for i=1:height
    for j=1:width
       h(k)=suppressed_image(i,j);
       k=k+1;
    end
end

A= sort(h);
length=size(A);
u=floor(length*0.89);
t_hi=A(u(1,2));
t_lo=t_hi*0.2;

Hyster = suppressed;

for i=1:height
    for j=1:width
        if Hyster(i,j) > t_hi
            Hyster(i,j)=255;
        elseif Hyster(i,j) > t_lo
            Hyster(i,j)=125;
        else
            Hyster(i,j)=0; 
        end
    end
end


end

