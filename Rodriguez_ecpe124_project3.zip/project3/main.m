% Project 3: 
% Writtrn By: Jacquelin Rodriguez

%-----Step 1: Convolve Image----

[FileName, FilePath]= uigetfile('*');
Image1=imread(strcat(FilePath, FileName));
if size(Image1,3) == 3
    grey_image = rgb2gray(Image1);
    grey_image=double(grey_image);
end
if size(Image1,3) ~= 3
    grey_image=Image1;
    grey_image=double(grey_image);
end

sigma=0.6;
[G_i,G_j, w]= GaussianKernel(sigma);
[G_deriv_i,G_deriv_j,w]= GaussianDerivativeKernel(sigma);

[con_h]=convolve(grey_image,G_j);
[con_horizontal]=convolve(con_h,fliplr(G_deriv_i));
figure('Name','Horizontal Convolve','NumberTitle','off')
imshow(con_horizontal)

[con_v]=convolve(grey_image,G_i);
[con_vertical]=convolve(con_v,flipud(G_deriv_j));
figure('Name','Vertical Convolve','NumberTitle','off')
imshow(con_vertical)

%----- Step 2: Magnitude and Gradient------

[Gxy, Iangle]=MagnitudeAndGradient(con_vertical,con_horizontal);

figure('Name','Gxy Image','NumberTitle','off')
imshow(uint8(Gxy))
figure('Name','Iangle Image','NumberTitle','off')
imshow(Iangle)

%------ Step 3: Suppression------
[suppressed_image] = Suppression( Gxy, Iangle);
figure('Name','Suppressed Image','NumberTitle','off')
imshow(uint8(suppressed_image))

% ----- Step 4: Hystersis-------
[ Hyster ] = Hysteresis(suppressed_image );
figure('Name','Hysteresis Image','NumberTitle','off');
imshow(Hyster)

%----- Step 5: Link Edges------
[Edges]=LinkEdges(Hyster);
figure('Name','Link Edges Image','NumberTitle','off');
imshow(uint8(Edges))

