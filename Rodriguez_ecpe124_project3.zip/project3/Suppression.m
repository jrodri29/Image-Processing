function [ suppressed_image ] = Suppression( Gxy, Iangle )

suppressed_image=Gxy;
[height, width]=size(Gxy);

for i=1:height
    for j=1:width 
        theta= Iangle(i,j);
        if theta < 0
            theta =theta+pi;
        end
        theta = (180/pi)*theta;
        if theta <= 22.5 || theta > 157.5 %
            if i > 1  && i < height 
                if Gxy(i,j)< Gxy(i-1,j) || Gxy(i,j) < Gxy(i+1, j)
                    suppressed_image(i,j)=0;
                end
            end
        elseif theta > 22.5  && theta <= 67.5
            if 1< j && j < width && 1< i && i < height
                if (Gxy(i,j) < Gxy(i-1, j-1) || Gxy(i,j) < Gxy(i+1, j+1)) 
                    suppressed_image(i,j) = 0;
                end
            end
        elseif theta > 67.5 && theta <= 112.5
            if 1 < j && j <width
                if Gxy(i,j) < Gxy(i,j-1) || Gxy(i,j) < Gxy(i, j+1) 
                    suppressed_image(i,j)=0;
                end
            end
        elseif theta > 112.5 && theta <= 157.5
            if 1< i && i< height && j < 1 && j < width
                if Gxy(i,j) < Gxy(i-1, j+1) || Gxy(i,j) < Gxy(i+1, j-1) 
                    suppressed_image(i,j)=0;
                end
            end
        else
            suppressed_image(i,j)= Gxy(i,j);
        end
    end
end

end

