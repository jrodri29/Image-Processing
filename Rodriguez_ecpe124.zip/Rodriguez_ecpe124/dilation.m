function [new_image_er] = dilation( Image2 )
%changes image to double and graps height/width
image_er= double(Image2);
[height, width] =size(image_er);
%sets ON and OFF values
ON=255;
OFF=0;
%sets new image equal to old image
new_image_er= image_er;
% produces dilated image with a SE of 3x3
for i=1:height
    for j=1:width
        if image_er(i,j) == ON
            new_image_er(i,j)= ON;
        end
        if i > 1
            if image_er(i-1,j) == ON  
                new_image_er(i,j)= ON;
            end
        end
        if j < width && i == height
            if image_er(i,j+1) == ON  
                new_image_er(i,j)= ON;
            end
        end
        if  j == width && i < height 
            if image_er(i+1,j) == ON  
                new_image_er(i,j)= ON;
            end
        end
        if j > 1 
            if image_er (i, j-1) == ON 
                new_image_er(i,j)= ON;
            end
        end
    end
end


end

