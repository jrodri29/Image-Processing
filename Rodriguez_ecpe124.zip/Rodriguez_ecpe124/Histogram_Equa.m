function [ new ] =Histogram_Equa( Image1 )

    [height, width] =size(Image1);%Find the height and width of image
    work_image=double(Image1);%convert image from uint8 to a double

    Histogram =zeros(256,1); %Create array with zeros to use in 
    L=256; % intensity level for grayscale image

    %Triverse every pixel to find the histogram, normalized histogram, CDF, and
    %historgram equalization 

    sum=0;

    for i=1:height
        for j=1:width
            intensity = work_image(i,j); %obtains the intensity level of the current pixel
            Histogram(intensity+1) = Histogram(intensity+1)+1; %computes histogram
        end
    end
    for k=1:L
        Histogram(k)= Histogram(k)/(width*height);%computes normalized histogram
        sum = sum + Histogram(k);% computes CDF
        Histogram(k)=sum;
        Histogram(k)=Histogram(k)*(L-1);% computes the histogram equalization
    end
    
    for i=1:height
        for j=1:width
            intensity = work_image(i,j);% obtains intensity level of current pixel
            work_image(i,j)= Histogram(intensity+1);% changes pixel intensity r(original) to the intensity form histogram equalization s(new)
        end
    end
    
    new = uint8(work_image);%convert image from double to uint8

end

