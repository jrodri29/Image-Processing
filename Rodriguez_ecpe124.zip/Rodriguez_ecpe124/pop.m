function [mod_froniter_i, mod_froniter_j, value_i, value_j,fp] = pop(froniter_i, froniter_j,fp)

value_i= froniter_i(fp); % gets i coordinate that will be popped
froniter_i(fp) =[]; % pops i coordinate off stack
mod_froniter_i = froniter_i; % stack is updated with amount of new elements

value_j= froniter_j(fp); % gets j coordinate that will be popped
froniter_j(fp) = []; % pops j coordinate off stack
mod_froniter_j = froniter_j; %stack is updated with the new amount of elements

fp=fp-1; %count of elements in stack is decreased by 1 since element was popped 
end

