% Project 1: Test Script ECPE 124
% Written By: Jacquelin Rodriguez
%% Histogram Eqaualization
%
%reads in image
[FileName, FilePath]= uigetfile('*');
Image1=imread(strcat(FilePath, FileName));
grey_image = rgb2gray(Image1);
%calls histogram function and displays image
Hist_Array=Histogram_Equa(grey_image);
imshow(Hist_Array)

%% Floodfill Froniter
%
%reads in image
[FileName, FilePath]= uigetfile('*');
image=imread(strcat(FilePath, FileName));
% asks user to pick seed form image
imshow(image)
[seed_j, seed_i]= ginput(1);
%sets new_color to white
new_color= [255,255,255];
% this checks to see if the image is grayscale or color
if size(image,3) == 3
    color_image= color_gray_floodfill(image, uint16(seed_i),uint16(seed_j), new_color);
    imshow(color_image) 
    
end
if size(image,3) == 1
    rgb_image = repmat(image,[1 1 3]);
    rgb_image = cat(3,image,image,image);
    grey_image= color_gray_floodfill(rgb_image, uint16(seed_i),uint16(seed_j), new_color);
    gray_threshold=rgb2gray(grey_image);
    imshow(grey_image) 
end

%% Floodfill Seperate Output
%
%reads in image
[FileName, FilePath]= uigetfile('*');
image=imread(strcat(FilePath, FileName));
%asks user to pick a seed from image
imshow(image)
[seed_j, seed_i]= ginput(1);
%sets color to white
new_color1= 255;
new_color2= 255;
new_color3= 255;
%this checks to see if image is grayscale or color
if size(image,3) == 3
    color_image= seperate_floodfill(image, uint16(seed_i),uint16(seed_j), new_color1,new_color2, new_color3, image);
    imshow(color_image) 
    
end
if size(image,3) == 1
    rgb_image = repmat(image,[1 1 3]);
    rgb_image = cat(3,image,image,image);
    grey_image= seperate_floodfill(rgb_image, uint16(seed_i),uint16(seed_j), new_color1,new_color2, new_color3, rgb_image);
    gray_threshold=rgb2gray(grey_image);
    imshow(grey_image) 
end


%% Double Threshold
% **(takes a little bit of time for function to run)**

%reads in image
[FileName, FilePath]= uigetfile('*');
thres=imread(strcat(FilePath, FileName));
% checks to see if image is grayscale or color 
if size(thres,3) == 3
    [output_new, low, high]= double_threshold(thres);
end
if size(thres,3) == 1
    rgb_image = repmat(thres,[1 1 3]);
    rgb_image = cat(3,thres,thres,thres);
    [output_new, low, high]= double_threshold(thres);
    gray_threshold=rgb2gray(output_new);
    gray_threshold2=rgb2gray(low);
    gray_threshold3=rgb2gray(high);   
end
%shows double threshold image
figure
imshow(output_new)

%% Erosion
%
%reads in image
[FileName, FilePath]= uigetfile('*');
Image1=imread(strcat(FilePath, FileName));
%calls erosionn function and displays image
er_image= erosion(Image1);
imshow(er_image)

%% Dilation
%
%reads in image
[FileName, FilePath]= uigetfile('*');
Image2=imread(strcat(FilePath, FileName));
%calls erosion function
di_image = dilation(Image2);
imshow(di_image)





