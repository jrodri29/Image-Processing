function [ new_image ] = color_gray_floodfill( color_image, seed_i,seed_j, new_color )

image = double(color_image); % image goes from uint8 to double
[height, width] =size(image);% get height and width of image
old_color = image(seed_i, seed_j); % the intensity of seed is saved 

% checking to see if old_color is the same as the new.  
if (old_color == new_color)
    return
end

%set stacks to be empty and pointer to 0
froniter_i =[];
froniter_j =[];
fp=0;

%calls push function on seed and sets new color
[froniter_i,froniter_j,fp] = push(froniter_i, froniter_j, seed_i, seed_j, fp);
image(seed_i, seed_j,1)= new_color(1);
image(seed_i, seed_j,2)= new_color(2);
image(seed_i, seed_j,3)= new_color(3);

%while loop that will loop until fp=0
while fp ~= 0
            [froniter_i, froniter_j,i, j,fp] = pop(froniter_i,froniter_j,fp);%calls pop function to remove element from stack
            
            if image(i-1,j) == old_color && j<= width && i > 1 %looks at top element 
              [froniter_i,froniter_j,fp]= push (froniter_i,froniter_j, i-1, j,fp);% if top element =old_color push it to stack
               image(i-1,j,1)= new_color(1);%change color
               image(i-1,j,2)= new_color(2);
               image(i-1,j,3)= new_color(3);
            end
            if image(i,j+1) == old_color && j > 1 %looks at left element
                [froniter_i,froniter_j,fp]=push(froniter_i, froniter_j,i, j+1, fp);% if left element =old_color push it to stack
                image(i, j+1,1) = new_color(1);%change color
                image(i, j+1,2) = new_color(2);
                image(i, j+1,3) = new_color(3);
            end
            if image(i+1,j) == old_color &&  i < height %looks at bottom element
               [froniter_i,froniter_j,fp]= push(froniter_i,froniter_j, i+1, j, fp);% if bottom element =old_color push it to stack
                image(i+1,j,1) = new_color(1);%change color
                image(i+1,j,2) = new_color(2);
                image(i+1,j,3) = new_color(3);
            end
            if image(i, j-1) == old_color && j > 1 %looks at right element
                [froniter_i,froniter_j,fp] = push(froniter_i, froniter_j, i, j-1,fp);% if right element =old_color push it to stack
                image(i, j-1,1) = new_color(1);%change color
                image(i, j-1,2) = new_color(2);
                image(i, j-1,3) = new_color(3);
            end
end         
%changes image from double to uint8
new_image = uint8(image);  

end

